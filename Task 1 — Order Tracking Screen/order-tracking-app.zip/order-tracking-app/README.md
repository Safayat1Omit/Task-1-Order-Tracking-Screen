# Order Tracking Screen

A redesigned mobile Order Tracking experience for an e-commerce app. Replaces a bare
4-status label with a clear delivery timeline, an at-a-glance status card, ETA,
order summary, and support/issue-reporting actions — and handles delayed orders,
"delivered but not received," and "tracking not available yet" as first-class states,
plus loading and error states.

**Live demo:** https://claude.ai/artifact/HSEysn9J5WimTsGx2gS6Xd

## Tech stack

Plain HTML, CSS, and vanilla JavaScript — no build step, no dependencies. This keeps
the demo trivial to run and deploy; the markup/JS is structured so each section
(status banner, timeline, ETA card, order summary, action buttons, bottom sheets)
maps cleanly onto components if you port it into React/Next.js.

## Project structure

```
.
├── index.html        # page shell
├── css/styles.css     # all styling, incl. dark-mode variables
├── js/app.js          # state machine + rendering + interactions
└── README.md
```

## Setup / run locally

No install or build required.

**Option A — just open it:**
Double-click `index.html`, or open it directly in a browser.

**Option B — serve it (recommended, avoids any local-file quirks):**
```bash
# from the project root
python3 -m http.server 8000
# then open http://localhost:8000
```
or, with Node installed:
```bash
npx serve .
```

## Trying the different states

A row of chips at the top of the screen lets you switch between every state without
needing a backend: Processing, Shipped, Out for delivery, Delivered, Delayed,
Delivered–not received, Tracking pending, Loading, and Error. This is how the three
required edge cases are demonstrated:

- **Delayed** — chip "Delayed"
- **Delivered but not received** — chip "Delivered–not received"
- **Tracking not available yet** — chip "Tracking pending"

Tapping the product row opens order details; the headset icon and any "Contact
support" / "Report an issue" button open a bottom sheet with mock actions.

## Deploying it live

Since this is a static site, any static host works with zero configuration:

**GitHub Pages (uses this same repo):**
1. Push this repo to GitHub.
2. Repo → Settings → Pages → Source: `Deploy from a branch` → Branch: `main` → `/ (root)`.
3. Your live URL will be `https://<your-username>.github.io/<repo-name>/`.

**Vercel / Netlify (drag-and-drop, no config):**
1. Go to vercel.com/new or app.netlify.com/drop.
2. Drag the project folder in, or connect the GitHub repo.
3. Deploy — you'll get a live URL immediately.

## Notes

- All data (order, ETA, items) is mocked in `js/app.js` — no backend integration.
- Designed for ~360–430px mobile widths; layout is fluid and centers on wider screens.
- Respects system light/dark mode automatically.
